import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

const EditRecipe = ({ recipes, onUpdateRecipe }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const [recipe, setRecipe] = useState(null);
  const [name, setName] = useState("");
  const [image, setImage] = useState("");
  const [ingredients, setIngredients] = useState([]);
  const [steps, setSteps] = useState([]);
  
  useEffect(() => {
    const foundRecipe = recipes.find((r) => r.id === parseInt(id));
    if (foundRecipe) {
      setRecipe(foundRecipe);
      setName(foundRecipe.name);
      setImage(foundRecipe.image);
      setIngredients(foundRecipe.ingredients);
      setSteps(foundRecipe.steps);
    }
  }, [id, recipes]);

  const handleIngredientChange = (index, value) => {
    const updatedIngredients = [...ingredients];
    updatedIngredients[index] = value;
    setIngredients(updatedIngredients);
  };

  const handleStepChange = (index, value) => {
    const updatedSteps = [...steps];
    updatedSteps[index] = value;
    setSteps(updatedSteps);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const updatedRecipe = {
      ...recipe,
      name,
      image,
      ingredients,
      steps,
    };
    onUpdateRecipe(updatedRecipe);
    navigate(`/detail-recipe/${id}`);
  };

  if (!recipe) {
    return <div>Recipe not found.</div>;
  }

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Edit Resep</h1>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block mb-2">Nama Resep:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="border rounded w-full p-2"
            required
          />
        </div>
        <div className="mb-4">
          <label className="block mb-2">URL Gambar:</label>
          <input
            type="text"
            value={image}
            onChange={(e) => setImage(e.target.value)}
            className="border rounded w-full p-2"
            required
          />
        </div>
        <div className="mb-4">
          <label className="block mb-2">Bahan:</label>
          {ingredients.map((ingredient, index) => (
            <input
              key={index}
              type="text"
              value={ingredient}
              onChange={(e) => handleIngredientChange(index, e.target.value)}
              className="border rounded w-full p-2 mb-2"
              required
            />
          ))}
          <button
            type="button"
            onClick={() => setIngredients([...ingredients, ""])}
            className="text-blue-500 hover:underline"
          >
            Tambah Bahan
          </button>
        </div>
        <div className="mb-4">
          <label className="block mb-2">Langkah-Langkah:</label>
          {steps.map((step, index) => (
            <input
              key={index}
              type="text"
              value={step}
              onChange={(e) => handleStepChange(index, e.target.value)}
              className="border rounded w-full p-2 mb-2"
              required
            />
          ))}
          <button
            type="button"
            onClick={() => setSteps([...steps, ""])}
            className="text-blue-500 hover:underline"
          >
            Tambah Langkah
          </button>
        </div>
        <button type="submit" className="bg-green-500 text-white p-2 rounded">
          Simpan Perubahan
        </button>
      </form>
    </div>
  );
};

export default EditRecipe;